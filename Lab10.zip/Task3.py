from textwrap import wrap
from gfxhat import lcd,  fonts
from PIL import Image, ImageFont, ImageDraw

def clearScreen(lcd):
    lcd.clear()
    lcd.show()

def displayObject(obj, x, y):
    lcd.clear()
    x_value = x
    y_value = y
    for y1 in obj:
        for x1 in y1:
            if x1 == 1:
                lcd.set_pixel(x + x_value, y + y_value, 1)

            elif x1 == 0:
                lcd.set_pixel(x + x_value, y + y_value, 0)

            x_value = x_value + 1
        y_value = y_value + 1
        x_value = x 
    lcd.show()

def generateDictionary():
    adictionary = {}

    with open('font3.txt') as afile:
        for line in afile:
            strippedline = line.strip()
            value, key = strippedline.split(',')
            splitlist = wrap(value, 2)
            del splitlist[0]
            valuelist = []
            for hexvalue in splitlist:
                astring = bin(int(hexvalue, 16))[2:].zfill(8)
                hexlist = []
                hexlist[:0] = astring
                int_map = map(int, hexlist)
                intlist = list(int_map)
                valuelist.append(intlist)

            adictionary[key] = valuelist
    return adictionary



x_value = 20
y_value = 20
thedictionary = generateDictionary()
user_character = input()

if user_character in thedictionary:
    displayObject(thedictionary[user_character], x_value, y_value)
    print(thedictionary[user_character])
else:
    print("This character is not in the dictionary!")

