import csv

with open('2000_BoysNames.txt', 'r') as afile:
    alist = []
    errorlist = []
    for line in afile:
        strippedline = line.strip()
        if ',' in strippedline:
            splitline = strippedline.split(',')
            alist.append(splitline)
        elif ' ' in strippedline:
            splitline = strippedline.split()
            alist.append(splitline)
        else:
            errorlist.append(strippedline)
        
    with open('BoysNames.csv', 'w', newline='') as newfile:
        writer = csv.writer(newfile)
        writer.writerow(('First Name', 'Count'))
        writer.writerows(alist)

    with open('BoysNamesError.csv', 'w', newline='') as newfile:
        writer = csv.writer(newfile)
        writer.writerows(errorlist)

with open('2000_GirlsNames.txt', 'r') as afile:
    alist = []
    errorlist = []
    for line in afile:
        strippedline = line.strip()
        if ',' in strippedline:
            splitline = strippedline.split(',')
            alist.append(splitline)
        elif ' ' in strippedline:
            splitline = strippedline.split()
            alist.append(splitline)
        else:
            errorlist.append(strippedline)
        
    with open('GirlsNames.csv', 'w', newline='') as newfile:
        writer = csv.writer(newfile)
        writer.writerow(('First Name', 'Count'))
        writer.writerows(alist)

    with open('GirlsNamesError.csv', 'w', newline='') as newfile:
        writer = csv.writer(newfile)
        writer.writerows(errorlist)