import csv

filelocation = input("Enter the file name/location: ")
with open(filelocation, newline='') as afile:
    filecontent = csv.reader(afile)
    alist = list(filecontent)

for innerlist in alist:
    print(innerlist)